<?php
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';

global $db, $langs, $user, $conf;

$langs->load("main");
$langs->load("womapeche@womapeche");

$id = GETPOST('id','int');
if (empty($id)) {
    setEventMessages($langs->trans("BonNotSpecified"), null, 'errors');
    header("Location: misenplat_select.php");
    exit;
}

// 🔹 Récupération du bon
$sql = "SELECT * FROM ".MAIN_DB_PREFIX."pech_bon_misenplat WHERE rowid = ".((int)$id);
$res = $db->query($sql);
$bon = $db->fetch_object($res);
if (!$bon) exit($langs->trans("BonNotFound"));

llxHeader("", $langs->trans("FeesAndServices")." - ".$langs->trans("Bon")." ".$bon->ref);

print '
<style>
.frais-container {
    max-width: 1200px;
    margin: 0 auto;
    background: #fff;
}

.frais-header {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #28a745;
}

.frais-header h1 {
    margin: 0;
    color: #2c3e50;
    font-size: 24px;
    font-weight: 600;
}

.info-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 6px;
    overflow: hidden;
    margin: 15px 0;
}

.info-table td {
    padding: 10px 15px;
    border-bottom: 1px solid #e9ecef;
}

.info-table tr:last-child td {
    border-bottom: none;
}

.frais-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 6px;
    overflow: hidden;
    margin: 20px 0;
}

.frais-table th {
    background: #e9ecef;
    color: #495057;
    padding: 12px 8px;
    font-weight: 600;
    text-align: left;
    border-bottom: 2px solid #dee2e6;
}

.frais-table td {
    padding: 10px 8px;
    border-bottom: 1px solid #e9ecef;
}

.frais-table tr:hover {
    background: #f8f9fa;
}

.form-input {
    padding: 6px 8px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
}

.form-input:focus {
    border-color: #80bdff;
    outline: 0;
    box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
}

.btn {
    display: inline-block;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s ease;
}

.btn-primary {
    background: #28a745;
    color: white;
}

.btn-primary:hover {
    background: #218838;
}

.btn-add {
    background: #17a2b8;
    color: white;
}

.btn-add:hover {
    background: #138496;
}

.btn-remove {
    background: #dc3545;
    color: white;
    padding: 4px 8px;
    font-size: 12px;
}

.btn-remove:hover {
    background: #c82333;
}

.actions-section {
    text-align: center;
    margin: 25px 0;
}

.total-section {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 6px;
    margin: 15px 0;
}

.total-input {
    background: #e9ecef;
    font-weight: 600;
    color: #495057;
    text-align: center;
}

@media (max-width: 768px) {
    .frais-container {
        padding: 10px;
    }
    
    .frais-table {
        font-size: 12px;
    }
    
    .frais-table th,
    .frais-table td {
        padding: 8px 6px;
    }
    
    .form-input {
        width: 100%;
    }
}
</style>
';

print '<div class="frais-container">';
print '<div class="frais-header">';
print '<h1><i class="fa fa-utensils"></i> '.$langs->trans("FeesAndServices").'</h1>';
print '</div>';

// 🔹 Infos du bon
print load_fiche_titre($langs->trans("PlatingBon")." : ".$bon->ref,'','fa-utensils');
print '<table class="info-table">';
print '<tr><td><strong>'.$langs->trans("Reference").'</strong></td><td>'.$bon->ref.'</td></tr>';
print '<tr><td><strong>'.$langs->trans("CreationDate").'</strong></td><td>'.$bon->date_creation.'</td></tr>';
print '<tr><td><strong>'.$langs->trans("Status").'</strong></td><td>'.($bon->statut==1 ? $langs->trans("Validated") : $langs->trans("Draft")).'</td></tr>';
print '<tr><td><strong>'.$langs->trans("Comment").'</strong></td><td>'.$bon->commentaire.'</td></tr>';
print '</table><br>';

// 🔹 Récupérer la liste des services depuis les produits type=1
$sql_service = "SELECT rowid, label, price AS pu FROM ".MAIN_DB_PREFIX."product WHERE fk_product_type = 1 ORDER BY label ASC";
$res_service = $db->query($sql_service);
$services = [];
while($s = $db->fetch_object($res_service)) {
    $services[] = $s;
}

// 🔹 Générer JSON pour JS
$services_json = json_encode($services);

// 🔹 Formulaire
print '<form id="form_frais" method="POST" action="frais_trait.php">';
print '<input type="hidden" name="fk_bon" value="'.$id.'">';
print '<input type="hidden" name="token" value="'.newToken().'">';

// 🔹 Tableau frais/services
print '<table class="frais-table" id="table_frais">';
print '<thead><tr class="liste_titre">';
print '<th>'.$langs->trans("Description").'</th>';
print '<th>'.$langs->trans("Quantity").'</th>';
print '<th>'.$langs->trans("UnitPrice").'</th>';
print '<th>'.$langs->trans("Total").'</th>';
print '<th>'.$langs->trans("Action").'</th>';
print '</tr></thead>';
print '<tbody>';
print '</tbody>';

// Bouton ajouter et total général
print '<tfoot>';
print '<tr><td colspan="5" align="center">';
print '<button type="button" id="addLineBtn" class="btn btn-add">';
print '<i class="fa fa-plus"></i> '.$langs->trans("AddLine");
print '</button>';
print '</td></tr>';
print '<tr><td colspan="3" align="right"><strong>'.$langs->trans("TotalGeneral").'</strong></td>';
print '<td colspan="2"><input type="text" id="total_general" class="form-input total-input" readonly value="0.00"></td></tr>';
print '</tfoot>';
print '</table><br>';

// Submit
print '<div class="actions-section">';
print '<input type="submit" class="btn btn-primary" value="'.$langs->trans("Save").'">';
print '</div>';
print '</form>';

// 🔹 Template de ligne (hors tableau)
print '<table style="display:none;">';
print '<tr id="ligneTemplate">';
print '<td><select name="desc[]" class="desc form-input" style="width:250px">';
print '<option value="">-- '.$langs->trans("ChooseService").' --</option>';
foreach($services as $s){
    print '<option value="'.dol_escape_htmltag($s->rowid).'">'.dol_escape_htmltag($s->label).'</option>';
}
print '</select></td>';
print '<td><input type="number" class="qty form-input" value="1" style="width:80px" name="qte[]"></td>';
print '<td><input type="number" step="0.01" class="pu form-input" value="0" style="width:100px" name="pu[]"></td>';
print '<td class="total_ligne">0.00</td>';
print '<td><button type="button" class="remove_line btn-remove"><i class="fa fa-trash"></i></button></td>';
print '</tr>';
print '</table>';

llxFooter();
?>

<script>
const services = <?php echo $services_json; ?>;

// 🔹 Calcul total ligne
function updateTotalRow(row){
    const qte = parseFloat(row.querySelector(".qty")?.value||0);
    const pu = parseFloat(row.querySelector(".pu")?.value||0);
    row.querySelector(".total_ligne").textContent = (qte*pu).toFixed(2);
    updateTotalGeneral();
}

// 🔹 Calcul total général
function updateTotalGeneral(){
    let total = 0;
    document.querySelectorAll("#table_frais tbody tr").forEach(tr=>{
        const val = parseFloat(tr.querySelector(".total_ligne")?.textContent||0);
        total += val;
    });
    document.getElementById("total_general").value = total.toFixed(2);
}

// 🔹 Ajouter ligne dynamique
document.getElementById("addLineBtn").addEventListener("click", ()=>{
    const tbody = document.querySelector("#table_frais tbody");
    const template = document.getElementById("ligneTemplate");
    const newRow = template.cloneNode(true);
    newRow.style.display = '';
    newRow.removeAttribute("id");

    // 🔹 Quand on change le service, remplir le PU
    const select = newRow.querySelector(".desc");
    const puInput = newRow.querySelector(".pu");
    select.addEventListener("change", ()=>{
        const service = services.find(s=>s.rowid == select.value);
        puInput.value = service ? parseFloat(service.pu).toFixed(2) : '0.00';
        updateTotalRow(newRow);
    });

    // 🔹 Recalcul quand on change Qte ou PU
    newRow.querySelectorAll("input").forEach(input=>{
        input.addEventListener("input", ()=>updateTotalRow(newRow));
    });

    // 🔹 Supprimer ligne
    newRow.querySelector(".remove_line").addEventListener("click", ()=>{
        newRow.remove();
        updateTotalGeneral();
    });

    tbody.appendChild(newRow);
});

// 🔹 Recalcul dynamique
document.addEventListener("input", e=>{
    if(e.target.classList.contains("qty") || e.target.classList.contains("pu")){
        updateTotalRow(e.target.closest("tr"));
    }
});
</script>
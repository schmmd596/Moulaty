<?php
/* Copyright (C) 2025
 * Abdou Mahfoudh <superadmin@womapeche.com>
 * All rights reserved.
 */

require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/stock/class/entrepot.class.php';

global $db, $langs, $user;

$langs->loadLangs(['womapeche@womapeche', 'main', 'other']);
$form = new Form($db);

// ============================================================================
// Paramètres
// ============================================================================
$id_bon = GETPOST('id', 'int');
if ($id_bon <= 0) {
    setEventMessages($langs->trans("Identifiant du bon invalide."), null, 'errors');
    header("Location: ./misenplat_select.php");
    exit;
}

// ============================================================================
// Récupération du bon
// ============================================================================
$sql_bon = "SELECT b.rowid, b.ref,b.fk_receptiondet, b.fk_entrepot, b.commentaire, b.statut,
                   e.ref as entrepot_ref
            FROM ".MAIN_DB_PREFIX."pech_bon_misenplat AS b
            LEFT JOIN ".MAIN_DB_PREFIX."entrepot AS e ON e.rowid = b.fk_entrepot
            WHERE b.rowid = ".((int)$id_bon);

$res_bon = $db->query($sql_bon);
if (!$res_bon || $db->num_rows($res_bon) == 0) {
    setEventMessages($langs->trans("Bon introuvable."), null, 'errors');
    header("Location: ./misenplat_select.php");
    exit;
}
$bon = $db->fetch_object($res_bon);

// ============================================================================
// Récupération des lignes du bon
// ============================================================================
// ============================================================================
// Récupération des lignes du bon avec gestion d'erreur
// ============================================================================
$produits = [];

if (!empty($bon->fk_receptiondet)) {
    // Nettoyage de la liste (évite injection et éléments invalides)
    $receptiondet_ids = array_filter(array_map('intval', explode(',', $bon->fk_receptiondet)));

    if (!empty($receptiondet_ids)) {
        $sql_lines = "SELECT m.rowid, m.fk_product, m.nombre_plat, m.poids_plat, 
                             p.ref as product_ref, p.label as product_label,
                             d.poids_net, d.poids_plater
                      FROM ".MAIN_DB_PREFIX."pech_misenplat AS m
                      LEFT JOIN ".MAIN_DB_PREFIX."product AS p ON p.rowid = m.fk_product
                      LEFT JOIN ".MAIN_DB_PREFIX."pech_receptiondet AS d ON d.rowid IN (".implode(',', $receptiondet_ids).")
                      WHERE m.fk_bon_misenplat = ".((int)$id_bon);

        $res_lines = $db->query($sql_lines);
        if (!$res_lines) {
            setEventMessages($langs->trans("Erreur lors de la récupération des lignes du bon : ").$db->lasterror(), null, 'errors');
            header("Location: ./misenplat_select.php");
            exit;
        }

        while ($obj = $db->fetch_object($res_lines)) {
            $produits[$obj->fk_product] = [
                'ref' => $obj->product_ref,
                'label' => $obj->product_label,
                'nombre_plat' => $obj->nombre_plat,
                'poids_plat' => $obj->poids_plat,
                'qte_totale' => $obj->poids_net,
                'qte_plater' => $obj->poids_plater
            ];
        }

        if (empty($produits)) {
            setEventMessages($langs->trans("Aucune ligne trouvée pour ce bon."), null, 'warnings');
        }
    } else {
        setEventMessages($langs->trans("Aucune ligne de réception valide pour ce bon."), null, 'warnings');
    }
} else {
    setEventMessages($langs->trans("Ce bon ne contient aucune ligne de réception."), null, 'warnings');
}

// ============================================================================
// Affichage
// ============================================================================
llxHeader('', $langs->trans("Modification du Bon de Mise en Plat"));
print load_fiche_titre($langs->trans("Bon de Mise en Plat : ".$bon->ref)." (Entrepôt : ".$bon->entrepot_ref.")", '', 'fa-utensils');

print '<form method="POST" action="./edit_trait.php">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="id_bon" value="'.$id_bon.'">';

print '<div class="div-table-responsive">';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre">';
print '<th>'.$langs->trans("Produit").'</th>';
print '<th class="right">'.$langs->trans("Quantité Totale (kg)").'</th>';
print '<th class="right">'.$langs->trans("Déjà Platée (kg)").'</th>';
print '<th class="right">'.$langs->trans("Reste à Plater (kg)").'</th>';
print '<th class="right">'.$langs->trans("Quantité à Plater (kg)").'</th>';
print '<th class="right">'.$langs->trans("Nombre de Plats").'</th>';
print '</tr>';

foreach ($produits as $id_prod => $prod) {
    $reste = max(0, $prod['qte_totale'] - $prod['qte_plater']);

    print '<tr class="oddeven">';
    print '<td>'.dol_escape_htmltag($prod['ref'].' - '.$prod['label']).'</td>';
    print '<td class="right">'.price($prod['qte_totale'], 2, '', 1).' kg</td>';
    print '<td class="right">'.price($prod['qte_plater'], 2, '', 1).' kg</td>';
    print '<td class="right">'.price($reste, 2, '', 1).' kg</td>';

    print '<td class="right">';
    print '<input type="number" step="0.01" name="qte_plater['.$id_prod.']" value="'.$prod['poids_plat']*$prod['nombre_plat'].'" min="0" max="'.$reste.'" class="flat right" style="width:90px;">';
    print '</td>';

    print '<td class="right">';
    print '<input type="number" name="nb_plat['.$id_prod.']" value="'.$prod['nombre_plat'].'" min="0" class="flat right" style="width:80px;">';
    print '</td>';

    print '</tr>';
}

print '</table>';
print '</div>';

print '<br><div class="center">';
print '<input type="submit" class="butAction" name="action_update" value="'.$langs->trans("Mettre à jour le Bon").'">';
print '&nbsp;';
print '<a class="button button-cancel" href="./misenplat_select.php">'.$langs->trans("Annuler").'</a>';
print '</div>';

print '</form>';

llxFooter();
$db->close();

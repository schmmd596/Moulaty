<?php
/* Copyright (C) 2025
 * Abdou Mahfoudh <superadmin@womapeche.com>
 * All rights reserved.
 */

require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';

global $db, $langs, $user, $conf;

$langs->loadLangs(['womapeche@womapeche', 'main', 'other']);

// Sécurité : uniquement POST et token valide


// Récupération des inputs
$id_bon = GETPOST('id_bon', 'int');
$qte_plater = GETPOST('qte_plater', 'array');
$nb_plat = GETPOST('nb_plat', 'array');
$commentaire = GETPOST('commentaire', 'alpha');

$selected = GETPOST('selected', 'array'); // tableau d'ids
// Normaliser la liste selected en entiers et enlever vides/non numériques
$selected_ids = array();
if (!empty($selected) && is_array($selected)) {
    foreach ($selected as $s) {
        $s = (int)$s;
        if ($s > 0) $selected_ids[] = $s;
    }
}

// Si on n'a pas de selected passé, récupérer le champ fk_receptiondet du bon comme fallback
if (empty($selected_ids) && $id_bon > 0) {
    $sql_bon = "SELECT fk_receptiondet FROM ".MAIN_DB_PREFIX."pech_bon_misenplat WHERE rowid = ".((int)$id_bon);
    $res_bon = $db->query($sql_bon);
    if ($res_bon && $db->num_rows($res_bon) > 0) {
        $obj_bon = $db->fetch_object($res_bon);
        if (!empty($obj_bon->fk_receptiondet)) {
            // fk_receptiondet stocké en chaîne "1,2,3" -> transformer en tableau d'entiers
            $parts = preg_split('/\s*,\s*/', $obj_bon->fk_receptiondet);
            foreach ($parts as $p) {
                $p = (int)$p;
                if ($p > 0) $selected_ids[] = $p;
            }
        }
    }
}

// Construire string sûr pour SQL IN
$selected_str = '';
if (!empty($selected_ids)) {
    // unique & numeric
    $selected_ids = array_values(array_unique($selected_ids));
    $selected_str = implode(',', $selected_ids);
}

// Validations basiques
if ($id_bon <= 0 || empty($qte_plater)) {
    setEventMessages($langs->trans("Données manquantes ou bon invalide."), null, 'errors');
    header("Location: ./list.php");
    exit;
}

// Vérification du statut du bon
$sql_check = "SELECT statut, ref, fk_entrepot FROM ".MAIN_DB_PREFIX."pech_bon_misenplat WHERE rowid = ".((int)$id_bon);
$res_check = $db->query($sql_check);
if ($res_check && $obj = $db->fetch_object($res_check)) {
    if ($obj->statut == 1) {
        setEventMessages($langs->trans("Le bon %s est déjà validé et ne peut pas être modifié.", $obj->ref), null, 'errors');
        header("Location: ./detail_mis.php?id=".$id_bon);
        exit;
    }
    $fk_entrepot = $obj->fk_entrepot;
} else {
    setEventMessages($langs->trans("Bon introuvable."), null, 'errors');
    header("Location: ./list.php");
    exit;
}

// Début transaction
$db->begin();
$error = 0;
$nb_insert = 0;

try {
    // 1) Mise à jour du commentaire
    $sql_bon = "UPDATE ".MAIN_DB_PREFIX."pech_bon_misenplat
                SET commentaire = '".$db->escape($commentaire)."'
                WHERE rowid = ".((int)$id_bon);
    if (!$db->query($sql_bon)) throw new Exception("Erreur lors de la mise à jour du bon");

    // 2) Récupération des lignes existantes pour suppression
    $res_old = $db->query("SELECT rowid, fk_product FROM ".MAIN_DB_PREFIX."pech_misenplat WHERE fk_bon_misenplat = ".((int)$id_bon));
    $old_lines = [];
    if ($res_old) {
        while ($obj_old = $db->fetch_object($res_old)) {
            // garder possibilité d'avoir plusieurs lignes par produit
            $old_lines[$obj_old->fk_product][] = $obj_old->rowid;
        }
    }

    // 3) Suppression des plats individuels liés aux anciennes lignes
    foreach ($old_lines as $lines) {
        foreach ($lines as $rowid) {
            $db->query("DELETE FROM ".MAIN_DB_PREFIX."pech_plat WHERE fk_misenplat = ".((int)$rowid));
        }
    }

    // 4) Suppression des anciennes lignes de mise en plat
    $db->query("DELETE FROM ".MAIN_DB_PREFIX."pech_misenplat WHERE fk_bon_misenplat = ".((int)$id_bon));

    // 5) Réinsertion des lignes et des plats (avec prix)
    foreach ($qte_plater as $fk_product => $qte_raw) {
        $fk_product = (int)$fk_product;
        $qte = (float)$qte_raw;
        $nb = (int)($nb_plat[$fk_product] ?? 0);
        if ($fk_product <= 0 || $qte <= 0 || $nb <= 0) continue;

        $poids_par_plat = $qte / $nb;

        // Insertion pech_misenplat
        $sql_line = "INSERT INTO ".MAIN_DB_PREFIX."pech_misenplat
                     (fk_bon_misenplat, fk_congelateur, fk_product, nombre_plat, poids_plat, statut, pointeur, commentaire, date_creation)
                     VALUES (
                         ".((int)$id_bon).",
                         ".((int)$fk_entrepot).",
                         ".((int)$fk_product).",
                         ".((int)$nb).",
                         ".$db->escape($poids_par_plat).",
                         0,
                         '".$db->escape($user->login)."',
                         '".$db->escape("Mis à jour manuellement")."',
                         NOW()
                     )";
        if (!$db->query($sql_line)) throw new Exception("Erreur lors de l'insertion de la ligne mise à jour pour le produit ".$fk_product);

        $fk_misenplat = $db->last_insert_id(MAIN_DB_PREFIX."pech_misenplat");

        // Si on n'a aucune sélection de réceptions, obtenir toutes réceptions non épuisées pour le produit (fallback)
        if (empty($selected_str)) {
            $sqlrec = "SELECT rd.rowid AS fk_receptiondet, rd.prix_moyen, rd.poids_net, rd.poids_plater
                       FROM ".MAIN_DB_PREFIX."pech_receptiondet AS rd
                       WHERE rd.fk_product = ".((int)$fk_product)."
                         AND rd.poids_net > rd.poids_plater
                       ORDER BY rd.rowid ASC";
        } else {
            $sqlrec = "SELECT rd.rowid AS fk_receptiondet, rd.prix_moyen, rd.poids_net, rd.poids_plater
                       FROM ".MAIN_DB_PREFIX."pech_receptiondet AS rd
                       WHERE rd.rowid IN (".$selected_str.")
                         AND rd.fk_product = ".((int)$fk_product)."
                       ORDER BY rd.rowid ASC";
        }

        $resrec = $db->query($sqlrec);
        if (!$resrec) throw new Exception("Erreur récupération réceptions pour produit ".$fk_product);

        $poids_total_restant = $qte;
        while ($objrec = $db->fetch_object($resrec)) {
            if ($poids_total_restant <= 0) break;

            $poids_restant_reception = (float)$objrec->poids_net - (float)$objrec->poids_plater;
            if ($poids_restant_reception <= 0) continue;

            $nb_plats_possibles = (int) floor($poids_restant_reception / $poids_par_plat);
            if ($nb_plats_possibles <= 0) continue;

            for ($i = 0; $i < $nb_plats_possibles; $i++) {
                if ($poids_total_restant <= 0) break;

                $prix_moyen_plat = (float)$objrec->prix_moyen * $poids_par_plat;

                $sql_plat = "INSERT INTO ".MAIN_DB_PREFIX."pech_plat
                             (fk_misenplat, fk_product, poids, prix_moyen, statut, date_creation)
                             VALUES (
                                 ".((int)$fk_misenplat).",
                                 ".((int)$fk_product).",
                                 ".$db->escape($poids_par_plat).",
                                 ".$db->escape($prix_moyen_plat).",
                                 0,
                                 NOW()
                             )";
                if (!$db->query($sql_plat)) throw new Exception("Erreur lors de l'ajout du plat pour la réception #".((int)$objrec->fk_receptiondet)." (produit ".$fk_product.")");

                // Optionnel : mettre à jour poids_plater sur la réceptiondet si tu veux marquer la consommation
                // $sql_up = "UPDATE ".MAIN_DB_PREFIX."pech_receptiondet SET poids_plater = poids_plater + ".$db->escape($poids_par_plat)." WHERE rowid = ".((int)$objrec->fk_receptiondet);
                // $db->query($sql_up);

                $poids_total_restant -= $poids_par_plat;
            }
        }

        if ($poids_total_restant > 0) {
            throw new Exception("Poids restant non attribué pour le produit ".$fk_product." (".(float)$poids_total_restant.")");
        }

        $nb_insert++;
    }

    // Commit
    $db->commit();
    setEventMessages($langs->trans("Bon de mise en plat mis à jour avec succès : %s (%s produits)", $id_bon, $nb_insert), null, 'mesgs');
    header("Location: ./detail_mis.php?id=".$id_bon);
    exit;

} catch (Exception $e) {
    $db->rollback();
    setEventMessages($e->getMessage(), null, 'errors');
    dol_syslog("Erreur mise à jour mise en plat : ".$e->getMessage(), LOG_ERR);
}

// En cas d'erreur affichage
llxHeader('', $langs->trans("Mise en Plat"));
print load_fiche_titre($langs->trans("Erreur lors de la Mise à jour"), '', 'fa-utensils');
print '<div class="error">'.$langs->trans("Une erreur s’est produite pendant le traitement.").'</div>';
print '<div class="center"><a class="button" href="./misenplat_select.php">'.$langs->trans("Retour").'</a></div>';
llxFooter();
$db->close();

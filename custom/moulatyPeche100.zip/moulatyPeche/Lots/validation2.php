<?php
// validate_lot_direct.php - Validation lot direct (création cartons et prix unitaire)
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';

global $db, $langs, $user;
$langs->load("abricot@abricot");

$id_lot = GETPOST('id', 'int');
if ($id_lot <= 0) {
    setEventMessages("⚠️ Lot non spécifié.", null, 'errors');
    header("Location: list_lot.php");
    exit;
}
if (empty($user->rights->moulatyPeche->read_r)) {
    accessforbidden('Accès réservé à l’administrateur.');
}

// Récupération du lot
$sqlLot = "SELECT * FROM ".MAIN_DB_PREFIX."pech_lot WHERE rowid=".$id_lot;
$resLot = $db->query($sqlLot);
if (!$resLot || $db->num_rows($resLot) == 0) {
    setEventMessages("❌ Lot introuvable.", null, 'errors');
    header("Location: list_lot.php");
    exit;
}
$lot = $db->fetch_object($resLot);

if ($lot->statut == 1) {
    setEventMessages("⚠️ Lot déjà validé.", null, 'warnings');
    header("Location: detail_lot.php?id=".$id_lot);
    exit;
}
if ( $lot->fk_entrepot <= 0 ){
     setEventMessages("⚠️ pas dentrepot.", null, 'warnings');
    header("Location: detail_lot.php?id=".$id_lot);
    exit;
}

// Récupération lignes de détail
$sqlLines = "SELECT * FROM ".MAIN_DB_PREFIX."pech_lotdet WHERE fk_lot=".$id_lot;
$resLines = $db->query($sqlLines);
$lines = [];
while ($obj = $db->fetch_object($resLines)) $lines[] = $obj;

$db->begin();
try {
    foreach ($lines as $line) {
        $nb_cartons = $line->nb_carton;
        $poids_par_carton = $line->poids_carton;
        $prix_unitaire = (float)$line->prix / $nb_cartons; // prix unitaire par carton

        // 🔹 Création des cartons pour chaque ligne
        for ($i=0; $i < $nb_cartons; $i++) {
            $sqlCarton = "INSERT INTO ".MAIN_DB_PREFIX."pech_carton
                          (fk_lotdet, fk_product, nb_plat, poids, fk_user_create, prix_moyen)
                          VALUES (
                              ".((int)$line->rowid).",
                              ".((int)$line->fk_product).",
                              ".((int)$line->plat_carton).",
                              ".((float)$poids_par_carton).",
                              ".((int)$user->id).",
                              ".((float)$prix_unitaire)."
                          )";
            if (!$db->query($sqlCarton)) {
                throw new Exception("Erreur création carton : ".$db->lasterror());
            }

            $fk_carton = $db->last_insert_id(MAIN_DB_PREFIX."pech_carton");

            // 🔹 Si des plats existent, les assigner à ce carton
            $sqlPlats = "SELECT rowid 
                         FROM ".MAIN_DB_PREFIX."pech_plat 
                         WHERE fk_misenplat = ".((int)$line->fk_misenplat)."
                         AND (fk_carton IS NULL OR fk_carton=0)
                         ORDER BY rowid ASC
                         LIMIT ".((int)$line->plat_carton);
            $resPlats = $db->query($sqlPlats);
            $platsDispo = [];
            while ($p = $db->fetch_object($resPlats)) $platsDispo[] = $p->rowid;

            if (!empty($platsDispo)) {
                $sqlUpdatePlats = "UPDATE ".MAIN_DB_PREFIX."pech_plat 
                                   SET fk_carton = ".((int)$fk_carton).",
                                       statut = 1
                                   WHERE rowid IN (".implode(',', array_map('intval', $platsDispo)).")";
                if (!$db->query($sqlUpdatePlats)) {
                    throw new Exception("Erreur assignation plats au carton : ".$db->lasterror());
                }
            }
        }

        // -----------------------------------------
        // 🔹 AJOUT MOUVEMENT DE STOCK POUR LA LIGNE
        // -----------------------------------------

        // Quantité totale à ajouter au stock
        $qty_total = $nb_cartons * $poids_par_carton;

        // Entrepôt obligatoire → je propose celui du lot
        $fk_entrepot = $lot->fk_entrepot > 0 ? $lot->fk_entrepot : 1;

        // Mouvement de stock
        dol_include_once('/product/stock/class/mouvementstock.class.php');

        $stock = new MouvementStock($db);

        $result = $stock->reception(
            $user,                     // utilisateur
            $line->fk_product,         // produit
            $fk_entrepot,              // entrepôt
            $qty_total,                // quantité (nb_cartons * poids_par_carton)
            0,                         // prix unitaire (facultatif)
            $langs->trans("Reception")." #LOT".$lot->ref  // libellé
        );

        if ($result < 0) {
            throw new Exception("Erreur mouvement stock : " . $stock->error);
        }
    }

    // Validation du lot
    $sql = "UPDATE ".MAIN_DB_PREFIX."pech_lot SET statut=1 WHERE rowid=".$id_lot;
    if (!$db->query($sql)) throw new Exception("Erreur validation lot : ".$db->lasterror());

    $db->commit();
    setEventMessages("✅ Lot <strong>{$lot->ref}</strong> validé et cartons créés avec prix unitaire.", null, 'mesgs');
} catch (Exception $e) {
    $db->rollback();
    setEventMessages($e->getMessage(), null, 'errors');
}

// Redirection vers le détail
header("Location: detail_lot.php?id=".$id_lot);
exit;
?>

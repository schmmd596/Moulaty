<?php
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';

global $db, $langs, $user;
$langs->load("abricot@abricot");

$id_lot = GETPOST('id', 'int');
if ($id_lot <= 0) {
    setEventMessages("⚠️ Lot non spécifié.", null, 'errors');
    header("Location: list_lot.php");
    exit;
}
if (empty($user->rights->moulatyPeche->read_r)) {
    accessforbidden('Accès réservé à l’administrateur.');
}

// Récupération du lot
$sqlLot = "SELECT * FROM ".MAIN_DB_PREFIX."pech_lot WHERE rowid=".$id_lot;
$resLot = $db->query($sqlLot);
if (!$resLot || $db->num_rows($resLot) == 0) {
    setEventMessages("❌ Lot introuvable.", null, 'errors');
    header("Location: list_lot.php");
    exit;
}
$lot = $db->fetch_object($resLot);

if ($lot->statut == 1) {
    setEventMessages("⚠️ Lot déjà validé.", null, 'warnings');
    header("Location: detail_lot.php?id=".$id_lot);
    exit;
}

// Récupération lignes de détail
$sqlLines = "SELECT * FROM ".MAIN_DB_PREFIX."pech_lotdet WHERE fk_lot=".$id_lot;
$resLines = $db->query($sqlLines);
$lines = [];
while ($obj = $db->fetch_object($resLines)) $lines[] = $obj;

$db->begin();
try {
    foreach ($lines as $line) {
    $nb_cartons = $line->nb_carton;
    $plat_par_carton = $line->plat_carton;
    $poids_par_carton = $line->poids_carton;

    // 🔹 Vérifier si ce lotdet est mixte
    $sqlMixte = "SELECT fk_misenplat, nb_plat 
                 FROM ".MAIN_DB_PREFIX."pech_lotdet_mixte_misenplat 
                 WHERE fk_lotdet_mixte = ".((int)$line->rowid);
    $resMixte = $db->query($sqlMixte);
    $platsDispo = [];

    if ($db->num_rows($resMixte) > 0) {
        // 🟢 CAS PRODUIT MIXTE : on combine les plats de plusieurs misenplat
        while ($mix = $db->fetch_object($resMixte)) {
            $sqlPlats = "SELECT rowid 
                         FROM ".MAIN_DB_PREFIX."pech_plat 
                         WHERE fk_misenplat = ".((int)$mix->fk_misenplat)." 
                         AND (fk_carton IS NULL OR fk_carton = 0)
                         ORDER BY rowid ASC
                         LIMIT ".((int)$mix->nb_plat);
            $resPlats = $db->query($sqlPlats);
            while ($obj = $db->fetch_object($resPlats)) {
                $platsDispo[] = $obj->rowid;
            }
        }
    } else {
        // 🟡 CAS NORMAL : un seul misenplat
        $sqlPlats = "SELECT rowid 
                    FROM ".MAIN_DB_PREFIX."pech_plat 
                    WHERE fk_misenplat = ".((int)$line->fk_misenplat)." 
                    AND (fk_carton IS NULL OR fk_carton = 0)
                    ORDER BY rowid ASC
                    LIMIT ".($nb_cartons * $plat_par_carton);
        $resPlats = $db->query($sqlPlats);
        while ($obj = $db->fetch_object($resPlats)) {
            $platsDispo[] = $obj->rowid;
        }
    }

    // 🧮 Vérification : y a-t-il assez de plats ?
    if (count($platsDispo) < $nb_cartons * $plat_par_carton) {
        throw new Exception("❌ Nombre de plats insuffisant pour le lotdet #".$line->rowid);
    }

    $indexPlat = 0;

    // 🔁 Création des cartons
    for ($i = 0; $i < $nb_cartons; $i++) {
        $sqlCarton = "INSERT INTO ".MAIN_DB_PREFIX."pech_carton
                     (fk_lotdet, fk_product, nb_plat, poids, fk_user_create)
                     VALUES (
                         ".((int)$line->rowid).",
                         ".((int)$line->fk_product).",
                         ".((int)$plat_par_carton).",
                         ".((float)$poids_par_carton).",
                         ".((int)$user->id)."
                     )";
        if (!$db->query($sqlCarton)) throw new Exception("Erreur création carton : ".$db->lasterror());

        $fk_carton = $db->last_insert_id(MAIN_DB_PREFIX."pech_carton");

        // 🔹 Assigner les plats à ce carton
        $platsPourCarton = array_slice($platsDispo, $indexPlat, $plat_par_carton);
        $indexPlat += $plat_par_carton;

        if (!empty($platsPourCarton)) {
            $sqlUpdatePlats = "UPDATE ".MAIN_DB_PREFIX."pech_plat 
                               SET fk_carton = ".((int)$fk_carton).",
                                   statut = 1
                               WHERE rowid IN (".implode(',', array_map('intval', $platsPourCarton)).")";
            if (!$db->query($sqlUpdatePlats)) throw new Exception("Erreur MAJ plats : ".$db->lasterror());
        }
    }

    
}
// 🔹 Mise à jour du nombre de plats sortis et du statut pour chaque misenplat lié à ce lot
$sqlUpdateMisenplat = "
    UPDATE ".MAIN_DB_PREFIX."pech_misenplat mp
    SET 
        nombre_plat_sortie = (
            SELECT COUNT(*) 
            FROM ".MAIN_DB_PREFIX."pech_plat p
            WHERE p.fk_misenplat = mp.rowid
            AND p.fk_carton IS NOT NULL
        ),
        statut = CASE 
                    WHEN nombre_plat_sortie >= nombre_plat THEN 2  -- Tous les plats sortis
                    WHEN nombre_plat_sortie > 0 THEN 1              -- Partiel
                    ELSE 0                                          -- Aucun plat sorti
                 END
    WHERE mp.rowid IN (
        -- 🔸 Tous les misenplat liés aux lignes simples du lot
        SELECT ld.fk_misenplat 
        FROM ".MAIN_DB_PREFIX."pech_lotdet ld
        WHERE ld.fk_lot = ".((int)$id_lot)."
        
        
    )
";
if (!$db->query($sqlUpdateMisenplat)) {
    throw new Exception("Erreur mise à jour misenplat : ".$db->lasterror());
}



    // Validation du lot
    $sql = "UPDATE ".MAIN_DB_PREFIX."pech_lot SET statut=1 WHERE rowid=".$id_lot;
    if (!$db->query($sql)) throw new Exception("Erreur validation lot : ".$db->lasterror());

// 🔹 Mise à jour du prix total pour chaque carton du lot
$sql_cartons = "
    SELECT c.rowid AS carton_id
    FROM ".MAIN_DB_PREFIX."pech_carton AS c
    INNER JOIN ".MAIN_DB_PREFIX."pech_lotdet AS ld ON ld.rowid = c.fk_lotdet
    WHERE ld.fk_lot = ".(int)$id_lot;

$res_cartons = $db->query($sql_cartons);
if (!$res_cartons) {
    throw new Exception("Erreur lors de la récupération des cartons : ".$db->lasterror());
}

if ($db->num_rows($res_cartons) == 0) {
    throw new Exception("Aucun carton trouvé pour le lot #".$id_lot);
}

while ($carton = $db->fetch_object($res_cartons)) {
    $carton_id = (int)$carton->carton_id;

    // 🔸 Calcul du prix total du carton à partir des plats
    $sql_sum = "
        SELECT SUM(prix_moyen + frais) AS prix_total_carton
        FROM ".MAIN_DB_PREFIX."pech_plat
        WHERE fk_carton = ".$carton_id;

    $res_sum = $db->query($sql_sum);
    if (!$res_sum) {
        throw new Exception("Erreur calcul somme pour carton #".$carton_id." : ".$db->lasterror());
    }

    $obj_sum = $db->fetch_object($res_sum);
    $prix_total_carton = (float) $obj_sum->prix_total_carton;

    if ($prix_total_carton <= 0) {
        // Pas de plats ou prix incohérent
        continue;
    }

    // 🔹 Mise à jour du carton
    $sql_update = "
        UPDATE ".MAIN_DB_PREFIX."pech_carton
        SET prix_moyen = ".$prix_total_carton."
        WHERE rowid = ".$carton_id;

    if (!$db->query($sql_update)) {
        throw new Exception("Erreur mise à jour carton #".$carton_id." : ".$db->lasterror());
    }
}


    $db->commit();
    setEventMessages("✅ Lot <strong>{$lot->ref}</strong> validé avec succès.", null, 'mesgs');
} catch (Exception $e) {
    $db->rollback();
    setEventMessages($e->getMessage(), null, 'errors');
}

// Redirection vers le détail
header("Location: detail_lot.php?id=".$id_lot);
exit;

<?php
// card.php - Formulaire création lot direct (sans traitement save)
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions.lib.php';

global $db, $user, $langs, $conf;
$langs->load("abricot@abricot");

$form = new Form($db);

$token = newToken();

// ======================
// Génération référence auto
// ======================
$res = $db->query("SELECT ref FROM ".MAIN_DB_PREFIX."pech_lot ORDER BY rowid DESC LIMIT 1");
$refPrev = ($res && $db->num_rows($res)) ? $db->fetch_object($res)->ref : '';

$nextNumber = (!empty($refPrev) && preg_match('/Lot-(\d+)/',$refPrev,$m)) ? ((int)$m[1]+1) : 1;
$ref = 'Lot-'.str_pad($nextNumber,6,'0',STR_PAD_LEFT);

// ======================
// Produits catégorie POISSON
// ======================
$products = [];
$sqlP = "
SELECT p.rowid, p.label
FROM ".MAIN_DB_PREFIX."product AS p
INNER JOIN ".MAIN_DB_PREFIX."categorie_product AS cp ON cp.fk_product = p.rowid
INNER JOIN ".MAIN_DB_PREFIX."categorie AS c ON c.rowid = cp.fk_categorie
WHERE c.label = 'POISSON'
ORDER BY p.label ASC";
$resP = $db->query($sqlP);
while ($obj = $db->fetch_object($resP)) $products[] = $obj;

// ======================
// Fournisseurs
// ======================
$fournisseurs = [];
$sqlF = "SELECT rowid, nom FROM ".MAIN_DB_PREFIX."societe WHERE fournisseur = 1 ORDER BY nom ASC";
$resF = $db->query($sqlF);
while ($o = $db->fetch_object($resF)) $fournisseurs[] = $o;

// ======================
// Entrepôts
// ======================
$TEntrepots = array();

$sqlW = "SELECT rowid, ref FROM ".MAIN_DB_PREFIX."entrepot WHERE statut = 1 ORDER BY ref ASC";
$resW = $db->query($sqlW);
if ($resW) {
    while ($obj = $db->fetch_object($resW)) {
        $TEntrepots[$obj->rowid] = $obj->ref;
    }
}

llxHeader('', $langs->trans("CreateDirectLot"));

print '
<style>
.facturation-container {
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    max-width: 1200px;
    margin: 0 auto;
    background: #fff;
}

.facturation-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 25px 30px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.facturation-header h1 {
    margin: 0;
    font-size: 28px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 12px;
}

/* Sections */
.facturation-info-section,
.facturation-services-section,
.facturation-total-section {
    background: #fff;
    border-radius: 12px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
}

.facturation-title {
    color: #2c3e50;
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 3px solid #3498db;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Grille d\'informations */
.facturation-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.info-item {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.info-item.full-width {
    grid-column: 1 / -1;
}

.info-item label {
    font-weight: 600;
    color: #555;
    font-size: 14px;
}

.info-value {
    padding: 10px 15px;
    background: #f8f9fa;
    border-radius: 6px;
    border: 1px solid #e9ecef;
    font-size: 15px;
}

.info-value.highlight {
    background: #e8f4fd;
    border-color: #3498db;
    color: #2c3e50;
    font-weight: 600;
}

/* Tableau des services */
.facturation-table-container {
    margin: 20px 0;
}

.facturation-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.facturation-table th {
    background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
    color: white;
    padding: 16px 12px;
    font-weight: 600;
    text-align: left;
    border: none;
    font-size: 14px;
}

.facturation-table th i {
    margin-right: 8px;
}

.facturation-table th.center {
    text-align: center;
}

.facturation-table td {
    padding: 14px 12px;
    border-bottom: 1px solid #e9ecef;
    vertical-align: middle;
}

.facturation-table td.center {
    text-align: center;
}

.facturation-table tr:last-child td {
    border-bottom: none;
}

.facturation-table tr:hover {
    background: #f8f9fa;
}

/* Champs de saisie */
.facturation-input {
    padding: 8px 10px;
    border: 1px solid #ced4da;
    border-radius: 6px;
    font-size: 14px;
    transition: all 0.3s ease;
    text-align: center;
}

.facturation-input:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
    outline: none;
}

.qte-input, .pu-input {
    width: 100px;
}

.total-input {
    width: 120px;
    background: #f8f9fa;
    font-weight: 600;
    color: #2c3e50;
}

.grand-total-input {
    width: 150px;
    padding: 12px 15px;
    font-size: 18px;
    font-weight: 700;
    text-align: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 8px;
}

/* Boutons */
.facturation-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
}

.facturation-btn.primary {
    background: #3498db;
    color: white;
}

.facturation-btn.primary:hover {
    background: #2980b9;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
}

.facturation-btn.success {
    background: #27ae60;
    color: white;
    padding: 12px 30px;
    font-size: 16px;
}

.facturation-btn.success:hover {
    background: #219a52;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(39, 174, 96, 0.3);
}

.facturation-btn.danger {
    background: #e74c3c;
    color: white;
    padding: 6px 12px;
    font-size: 12px;
}

.facturation-btn.danger:hover {
    background: #c0392b;
}

/* Sections d\'actions */
.facturation-actions {
    display: flex;
    gap: 15px;
    margin: 20px 0;
}

.facturation-submit-section {
    text-align: center;
    margin: 30px 0;
}

.submit-btn {
    padding: 15px 40px;
    font-size: 16px;
    border-radius: 8px;
}

/* Section total */
.facturation-total-section {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border: 2px solid #3498db;
}

.total-grid {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.total-label {
    font-size: 20px;
    font-weight: 700;
    color: #2c3e50;
}

.total-value {
    display: flex;
    align-items: center;
    gap: 15px;
}

/* Noms des services */
.service-name {
    display: flex;
    align-items: center;
    gap: 8px;
}

.error-text {
    color: #e74c3c;
    font-weight: 600;
}

/* Styles spécifiques pour ce formulaire */
.lot-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.form-group label {
    font-weight: 600;
    color: #555;
    font-size: 14px;
}

.form-control {
    padding: 10px 15px;
    border: 1px solid #ced4da;
    border-radius: 6px;
    font-size: 15px;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
    outline: none;
}

.form-control[disabled] {
    background: #e9ecef;
    color: #6c757d;
}

/* Responsive */
@media (max-width: 768px) {
    .facturation-container {
        padding: 10px;
    }
    
    .facturation-info-grid {
        grid-template-columns: 1fr;
    }
    
    .facturation-table {
        font-size: 12px;
    }
    
    .facturation-table th,
    .facturation-table td {
        padding: 10px 8px;
    }
    
    .total-grid {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
    
    .qte-input, .pu-input {
        width: 80px;
    }
    
    .total-input {
        width: 100px;
    }
    
    .lot-form-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .facturation-header {
        padding: 20px;
    }
    
    .facturation-header h1 {
        font-size: 22px;
    }
    
    .facturation-info-section,
    .facturation-services-section,
    .facturation-total-section {
        padding: 15px;
    }
    
    .facturation-title {
        font-size: 18px;
    }
}
</style>
';

print '<div class="facturation-container">';
print '<div class="facturation-header">';
print '<h1><i class="fa fa-cube"></i> '.$langs->trans("CreateDirectLot").'</h1>';
print '</div>';

// ======================
// FORM
// ======================
print '<form method="POST" action="save_lot.php">';
print '<input type="hidden" name="token" value="'.$token.'">';
print '<input type="hidden" name="action" value="save">';
print '<input type="hidden" name="source_type" value="1">';  // Direct

// ---- Infos principales
print '<div class="facturation-info-section">';
print '<div class="facturation-title">';
print '<i class="fa fa-info-circle"></i> '.$langs->trans("BasicInformation");
print '</div>';

print '<div class="lot-form-grid">';
print '<div class="form-group">';
print '<label>'.$langs->trans("LotReference").'</label>';
print '<input type="text" class="form-control" value="'.$ref.'" disabled>';
print '<input type="hidden" name="ref" value="'.$ref.'">';
print '</div>';

print '<div class="form-group">';
print '<label>'.$langs->trans("Supplier").'</label>';
print $form->select_company('', 'fk_fournisseur', 0, null, 0, '', 1);
print '</div>';

print '<div class="form-group">';
print '<label>'.$langs->trans("Warehouse").'</label>';
print $form->selectarray('fk_entrepot', $TEntrepots, '', 1);
print '</div>';

print '<div class="form-group full-width">';
print '<label>'.$langs->trans("Comment").'</label>';
print '<textarea name="commentaire" class="form-control" rows="3"></textarea>';
print '</div>';
print '</div>';
print '</div>';

// ---- Lignes du lot
print '<div class="facturation-services-section">';
print '<div class="facturation-title">';
print '<i class="fa fa-list-alt"></i> '.$langs->trans("LotDetails");
print '</div>';

print '<div class="facturation-table-container">';
print '<table class="facturation-table" id="tableLines">';
print '<thead>';
print '<tr>';
print '<th><i class="fa fa-cube"></i> '.$langs->trans("Product").'</th>';
print '<th class="center"><i class="fa fa-box"></i> '.$langs->trans("NbCartons").'</th>';
print '<th class="center"><i class="fa fa-weight"></i> '.$langs->trans("WeightPerCarton").'</th>';
print '<th class="center"><i class="fa fa-money-bill"></i> '.$langs->trans("Price").' ('.$conf->currency.')</th>';
print '<th><i class="fa fa-comment"></i> '.$langs->trans("Comment").'</th>';
print '<th class="center"><i class="fa fa-cog"></i> '.$langs->trans("Actions").'</th>';
print '</tr>';
print '</thead>';
print '<tbody>';

print '<tr class="lineRow">';
print '<td>';
print '<select name="product_id[]" class="form-control"><option value="">-- '.$langs->trans("SelectProduct").' --</option>';
foreach ($products as $p) {
    print '<option value="'.$p->rowid.'">'.htmlspecialchars($p->label).'</option>';
}
print '</select>';
print '</td>';

print '<td class="center">';
print '<input type="number" name="nb_carton[]" value="0" min="0" class="form-control qte-input nb">';
print '</td>';

print '<td class="center">';
print '<input type="text" name="poids_carton[]" value="20" class="form-control pu-input poids">';
print '</td>';

print '<td class="center">';
print '<input type="text" name="prix[]" value="0" class="form-control total-input prix">';
print '</td>';

print '<td>';
print '<input type="text" name="line_comment[]" class="form-control">';
print '</td>';

print '<td class="center">';
print '<button type="button" class="facturation-btn danger removeLine">';
print '<i class="fa fa-trash"></i> '.$langs->trans("Remove");
print '</button>';
print '</td>';
print '</tr>';

print '</tbody>';
print '</table>';
print '</div>';

print '<div class="facturation-actions">';
print '<button type="button" id="addLine" class="facturation-btn primary">';
print '<i class="fa fa-plus"></i> '.$langs->trans("AddLine");
print '</button>';
print '</div>';
print '</div>';

// Total lot
print '<div class="facturation-total-section">';
print '<div class="total-grid">';
print '<div class="total-label">';
print '<i class="fa fa-calculator"></i> '.$langs->trans("TotalLot");
print '</div>';
print '<div class="total-value">';
print '<span class="grand-total-input" id="total_lot">0 '.$conf->currency.'</span>';
print '</div>';
print '</div>';
print '</div>';

// Bouton de soumission
print '<div class="facturation-submit-section">';
print '<input type="submit" class="facturation-btn success submit-btn" value="'.$langs->trans("CreateLot").'">';
print '</div>';

print '</form>';
print '</div>';

llxFooter();
?>

<script>
function calcTotal() {
    let total = 0;
    document.querySelectorAll('#tableLines .lineRow').forEach(row => {
        let nb = parseFloat(row.querySelector('.nb').value) || 0;
        let poids = parseFloat(row.querySelector('.poids').value) || 0;
        let prix = parseFloat(row.querySelector('.prix').value) || 0;
        total += prix;
    });
    document.getElementById('total_lot').innerText = total.toFixed(2) + ' <?php echo $conf->currency; ?>';
}

document.querySelectorAll('#tableLines').forEach(tbl => {
    tbl.addEventListener('input', calcTotal);
});

document.getElementById('addLine').addEventListener('click', function(){
    let row = document.querySelector('.lineRow').cloneNode(true);
    row.querySelectorAll('input').forEach(i => {
        if(i.type !== 'hidden') i.value = '';
    });
    row.querySelector('.poids').value = '20';
    row.querySelector('.nb').value = '0';
    row.querySelector('.prix').value = '0';
    document.querySelector('#tableLines tbody').appendChild(row);
    bindRemove();
    calcTotal();
});

function bindRemove(){
    document.querySelectorAll('.removeLine').forEach(btn=>{
        btn.onclick = function(){
            if(document.querySelectorAll('.lineRow').length > 1){
                this.closest('tr').remove();
                calcTotal();
            }
        }
    });
}
bindRemove();

// Calcul initial
calcTotal();
</script>
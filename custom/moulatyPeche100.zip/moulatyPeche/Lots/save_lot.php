<?php
// save_lot.php - Traitement création lot direct sans cartons, avec try/catch
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions.lib.php';

global $db, $user, $langs;
$langs->load("abricot@abricot");

$action      = GETPOST('action', 'alpha');
$token       = GETPOST('token', 'alpha');
$ref         = GETPOST('ref', 'alpha');
$fk_fourn    = GETPOST('fk_fournisseur', 'int');
$fk_entrepot = GETPOST('fk_entrepot', 'int');
$commentaire = GETPOST('commentaire', 'restricthtml');
$source_type = GETPOST('source_type', 'int');

// lignes
$lines_product    = GETPOST('product_id', 'array');
$lines_nb_carton  = GETPOST('nb_carton', 'array');
$lines_poids_carton = GETPOST('poids_carton', 'array');
$lines_prix       = GETPOST('prix', 'array');
$lines_comment    = GETPOST('line_comment', 'array');


try {
    // Vérifications basiques
    if ($action !== 'save' || $token != newToken()) throw new Exception($langs->trans("BadToken"));
    if (empty($fk_fourn)  or $fk_fourn <= 0) throw new Exception($langs->trans("SupplierMissing"));
    if (empty($fk_entrepot) or $fk_entrepot <= 0) throw new Exception($langs->trans("EntrepotMissing"));
    if (empty($lines_product) || count($lines_product) == 0) throw new Exception($langs->trans("NoLines"));

    // Vérifier référence dernière
    $res = $db->query("SELECT ref FROM ".MAIN_DB_PREFIX."pech_lot ORDER BY rowid DESC LIMIT 1");
    $lastRef = ($res && $db->num_rows($res) > 0) ? $db->fetch_object($res)->ref : '';
    if ($lastRef != $ref) {
        $nextNumber = (!empty($lastRef) && preg_match('/Lot-(\d+)/',$lastRef,$m)) ? ((int)$m[1]+1) : 1;
        $ref = 'Lot-'.str_pad($nextNumber,6,'0',STR_PAD_LEFT);
    }

    // Vérifier lignes valides
    $validLines = [];
    foreach ($lines_product as $i => $prod) {
        $prod = (int)$prod;
        $nb   = isset($lines_nb_carton[$i]) ? (int)$lines_nb_carton[$i] : 0;
        $poids= isset($lines_poids_carton[$i]) ? (float)str_replace(',', '.', $lines_poids_carton[$i]) : 0.0;
        $prix = isset($lines_prix[$i]) ? (float)str_replace(',', '.', $lines_prix[$i]) : 0.0;
        $com  = isset($lines_comment[$i]) ? $db->escape($lines_comment[$i]) : '';

        if ($prod > 0 && $nb > 0) {
            $validLines[] = [
                'product' => $prod,
                'nb_carton' => $nb,
                'poids_carton' => $poids,
                'prix' => $prix,
                'comment' => $com
            ];
        }
    }
    if (empty($validLines)) throw new Exception($langs->trans("NoValidLines"));

    // =========================
    // Tout est OK, début transaction
    // =========================
    $db->begin();

    // Ajouter info que lot créé par réception directe
    $commentaire .= "\nLot créé par réception directe des cartons.";

    // Insert pech_lot
    $sql = "INSERT INTO ".MAIN_DB_PREFIX."pech_lot
            (ref, fk_user_create, fk_entrepot, fk_bonentree, source_type,fk_fourn, fk_facture, total_frais, date_creation, commentaire, statut, entity)
            VALUES (
                '".$db->escape($ref)."',
                ".((int)$user->id).",
                ".((int)$fk_entrepot).",
                NULL,
                ".((int)$source_type).",
                ".((int)$fk_fourn).",
                NULL,
                0,
                NOW(),
                '".$db->escape($commentaire)."',
                0,
                1
            )";
    if (!$db->query($sql)) throw new Exception("Erreur création lot: ".$db->lasterror());
    $id_lot = $db->last_insert_id(MAIN_DB_PREFIX."pech_lot");

    // Insert lignes lotdet
    foreach ($validLines as $ln) {
        $sqlDet = "INSERT INTO ".MAIN_DB_PREFIX."pech_lotdet
                   (fk_lot, fk_product, fk_misenplat, source_type, poids_carton, plat_carton, nb_carton, taux_rendement, commentaire, prix, date_creation, statut, entity)
                   VALUES (
                       ".(int)$id_lot.",
                       ".(int)$ln['product'].",
                       NULL,
                       ".((int)$source_type).",
                       ".(float)$ln['poids_carton'].",
                       0,
                       ".(int)$ln['nb_carton'].",
                       100,
                       '".$db->escape($ln['comment'])."',
                       ".(float)$ln['prix'].",
                       NOW(),
                       0,
                       1
                   )";
        if (!$db->query($sqlDet)) throw new Exception("Erreur insertion lotdet: ".$db->lasterror());
    }

    // Commit transaction
    $db->commit();
    setEventMessages($langs->trans("LotCreatedSuccess"), null, 'mesgs');
    header("Location: detail_lot.php?id=".$id_lot);
    exit;

} catch (Exception $e) {
    // Rollback si erreur
    if ($db->status === 'begin') $db->rollback();
    setEventMessages($e->getMessage(), null, 'errors');
    // Retour vers la page de réception
    header("Location: recep_cart.php");
    exit;
}
?>

<?php
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';

global $db, $user;

$id = GETPOST('id', 'int');

if (!$id) {
    setEventMessages("ID de la sortie manquant.", null, 'errors');
    header("Location: detail.php");
    exit;
}

if (empty($user->rights->moulatyPeche->read_r)) {
    accessforbidden('Accès réservé à l’administrateur.');
}

$db->begin();

try {
    // 1️⃣ Récupération de la sortie
    $sql = "SELECT * FROM ".MAIN_DB_PREFIX."pech_sortie WHERE rowid = ".((int)$id);
    $res = $db->query($sql);
    $sortie = $db->fetch_object($res);

    if (!$sortie) throw new Exception("Sortie introuvable.");
    if ($sortie->statut != 0) throw new Exception("La sortie n'est plus modifiable.");
    //if ($sortie->type != 1) throw new Exception("Ce script ne traite que les transferts internes.");

    // 2️⃣ Lignes produits
    $sqlProd = "SELECT * FROM ".MAIN_DB_PREFIX."pech_sortiedetprod WHERE fk_sortie = ".((int)$id);
    $resProd = $db->query($sqlProd);
    if ($db->num_rows($resProd) == 0) throw new Exception("Aucun produit dans la sortie.");

    // 3️⃣ Création du nouveau lot
    $resLast = $db->query("SELECT ref FROM ".MAIN_DB_PREFIX."pech_lot ORDER BY rowid DESC LIMIT 1");
    $ref1 = '';
    if ($resLast && $db->num_rows($resLast) > 0) {
        $obj2 = $db->fetch_object($resLast);
        $ref1 = $obj2->ref;
    }
    $nextNumber = (!empty($ref1) && preg_match('/Lot-(\d+)/', $ref1, $m)) ? ((int)$m[1] + 1) : 1;
    $refLot = 'Lot-' . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);

    /*$sqlLot = "INSERT INTO ".MAIN_DB_PREFIX."pech_lot (ref, fk_user_create, fk_entrepot, commentaire, statut, entity)
               VALUES ('".$db->escape($refLot)."', ".((int)$user->id).", ".((int)$sortie->fk_entrepot_dest).",
               'Créé automatiquement depuis la sortie #".$sortie->ref."', 1, 1)"; // statut = 0 pour en stock
    $db->query($sqlLot);
    $lot_id = $db->last_insert_id(MAIN_DB_PREFIX.'pech_lot');*/

    // 4️⃣ Pour chaque produit
    while ($objProd = $db->fetch_object($resProd)) {

        // 🔹 NORMALISATION DES PRIX (IMPORTANT!)
        // Calcule le prix moyen de TOUS les cartons du produit dans l'entrepôt source
        // Puis met à jour tous les cartons pour avoir le MÊME prix moyen
        // Cela garantit que retirer des cartons ne change JAMAIS la moyenne des cartons restants
        $sqlPrixMoyenTotal = "SELECT
                                SUM(c.prix_moyen + c.frais) / COUNT(c.rowid) as prix_moyen_total
                             FROM ".MAIN_DB_PREFIX."pech_carton c
                             INNER JOIN ".MAIN_DB_PREFIX."pech_lotdet ld ON c.fk_lotdet = ld.rowid
                             INNER JOIN ".MAIN_DB_PREFIX."pech_lot l ON ld.fk_lot = l.rowid
                             WHERE c.fk_product = ".((int)$objProd->fk_product)."
                             AND l.fk_entrepot = ".((int)$sortie->fk_entrepot_source)."
                             AND c.statut = 0";
        $resPrixMoyenTotal = $db->query($sqlPrixMoyenTotal);
        $prix_moyen_total = 0;
        if ($resPrixMoyenTotal && $db->num_rows($resPrixMoyenTotal) > 0) {
            $objPrixTotal = $db->fetch_object($resPrixMoyenTotal);
            $prix_moyen_total = (float)$objPrixTotal->prix_moyen_total;

            // Mettre à jour TOUS les cartons du produit avec ce prix moyen normalisé
            // Cela assure que tous les cartons ont le MÊME prix
            $db->query("UPDATE ".MAIN_DB_PREFIX."pech_carton
                        SET prix_moyen = ".((float)$prix_moyen_total).", frais = 0
                        WHERE fk_product = ".((int)$objProd->fk_product)."
                        AND rowid IN (
                            SELECT c.rowid FROM ".MAIN_DB_PREFIX."pech_carton c
                            INNER JOIN ".MAIN_DB_PREFIX."pech_lotdet ld ON c.fk_lotdet = ld.rowid
                            INNER JOIN ".MAIN_DB_PREFIX."pech_lot l ON ld.fk_lot = l.rowid
                            WHERE l.fk_entrepot = ".((int)$sortie->fk_entrepot_source)."
                            AND c.statut = 0
                        )");
        }

        // 4.1 Détail du lot (code commenté comme original)

        // 4.2 Transfert des cartons liés
        $sqlCarton = "SELECT * FROM ".MAIN_DB_PREFIX."pech_sortiedetcarton WHERE fk_sortiedetprod = ".((int)$objProd->rowid);
        $resCarton = $db->query($sqlCarton);
        if ($db->num_rows($resCarton) > 0) {
            // Mise à jour des anciens cartons : statut = 1 (sortie)
            // Après normalisation, tous les cartons ont le même prix, donc retirer certains ne change pas la moyenne
            $db->query("UPDATE ".MAIN_DB_PREFIX."pech_carton SET statut = 1 WHERE rowid IN (
                SELECT fk_carton FROM ".MAIN_DB_PREFIX."pech_sortiedetcarton WHERE fk_sortiedetprod = ".((int)$objProd->rowid)."
            )");
        }

        // 4.3 Mouvement de stock (code commenté comme original)
    }

    // 5️⃣ Validation de la sortie
    $db->query("UPDATE ".MAIN_DB_PREFIX."pech_sortie SET statut = 1 WHERE rowid = ".((int)$id));

    $db->commit();
    setEventMessages("Sortie validée et transférée avec succès vers l'entrepôt de destination.", null, 'mesgs');
    header("Location: detail.php?id=".$id);
    exit;

} catch (Exception $e) {
    $db->rollback();
    setEventMessages("Erreur : ".$e->getMessage(), null, 'errors');
    header("Location: detail.php?id=".$id);
    exit;
}
?>

<?php
/**
 * Vente Client - Redirection vers Sortie Client
 */

require '../../../main.inc.php';

// Redirection automatique vers la page de création
header("Location: " . dol_buildpath('/custom/moulatyPeche/vente_client/sortie_client.php', 1));
exit;
?>

<?php
/**
 * Vente Client - Création Complète (Sortie + Validation + Facture en une étape)
 */

require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

global $db, $user, $langs, $conf;
$langs->loadLangs(['stocks', 'main', 'moulatyPeche@moulatyPeche']);

if (!$user->rights->moulatyPeche->read_v) {
    die("Accès refusé");
}

$form = new Form($db);
$action = GETPOST('action', 'alpha');
$db_in_transaction = false;

// ============================================================================
// TRAITEMENT COMPLET : CRÉATION + VALIDATION + FACTURE
// ============================================================================
if ($action === 'create') {
    // Vérifier le token CSRF
    if (!GETPOST('token')) {
        setEventMessages("Token de sécurité manquant", '', 'errors');
        header("Location: sortie_client.php");
        exit;
    }

    try {
        // Récupérer les données
        $fk_client = intval(GETPOST('fk_client_dest', 'int'));
        $montant_paye = floatval(GETPOST('montant_paye', 'float'));
        $products = GETPOST('products', 'array');
        $cartons_post = GETPOST('nb_carton', 'array');
        $prix_carton_post = GETPOST('prix_carton', 'array');
        $entrepots_post = GETPOST('fk_entrepot_source_prod', 'array');
        $numero_camion_post = GETPOST('numero_camion_prod', 'array');

        if (!is_array($products) || count($products) == 0) throw new Exception("Aucun produit fourni");

        // Vérifier les permissions d'accès aux entrepôts
        if (!$user->admin) {
            // Récupérer les entrepôts autorisés pour cet utilisateur
            $sql_user_ent = "SELECT fk_entrepot FROM ".MAIN_DB_PREFIX."user_entrepot WHERE fk_user = " . $user->id;
            $res_user_ent = $db->query($sql_user_ent);
            $allowed_entrepots = array();
            while ($obj = $db->fetch_object($res_user_ent)) {
                $allowed_entrepots[] = $obj->fk_entrepot;
            }

            // Vérifier que tous les entrepôts demandés sont autorisés
            foreach ($entrepots_post as $ent_id) {
                if ($ent_id > 0 && !in_array($ent_id, $allowed_entrepots)) {
                    throw new Exception("Accès refusé: vous n'avez pas accès à cet entrepôt");
                }
            }
        }

        // Construire les lignes de produits
        $product_lines = array();
        $total_vente = 0;
        $poids_total = 0;
        $nb_carton_total = 0;
        $entrepot_source = null;

        foreach ($products as $idx => $product_id) {
            $product_id = intval($product_id);
            if ($product_id <= 0) continue;

            $nb_carton = isset($cartons_post[$idx]) ? intval($cartons_post[$idx]) : 0;
            $prix = isset($prix_carton_post[$idx]) ? floatval($prix_carton_post[$idx]) : 0;
            $entrepot = isset($entrepots_post[$idx]) ? intval($entrepots_post[$idx]) : 0;
            $numero_camion = isset($numero_camion_post[$idx]) ? trim($numero_camion_post[$idx]) : '';

            if ($nb_carton > 0 && $prix > 0) {
                // Vérifier que tous les produits viennent du même entrepôt
                if ($entrepot_source === null) {
                    $entrepot_source = $entrepot;
                } elseif ($entrepot_source !== $entrepot) {
                    throw new Exception("Tous les produits doivent provenir du même entrepôt");
                }

                $ligne_total = $nb_carton * $prix;
                $total_vente += $ligne_total;
                $poids_total += ($nb_carton * 25); // 25 kg par carton
                $nb_carton_total += $nb_carton;

                $product_lines[] = array(
                    'product_id' => $product_id,
                    'nb_carton' => $nb_carton,
                    'prix_carton' => $prix,
                    'total' => $ligne_total,
                    'entrepot' => $entrepot,
                    'poids' => ($nb_carton * 25),
                    'numero_camion' => $numero_camion
                );
            }
        }

        if (count($product_lines) == 0 || $total_vente <= 0) {
            throw new Exception("Aucun produit valide avec Cartons > 0 ET Prix > 0");
        }

        if ($entrepot_source === null || $entrepot_source <= 0) {
            throw new Exception("Entrepôt source invalide");
        }

        // Valider montant payé
        if ($montant_paye > $total_vente) {
            throw new Exception("Montant payé ne peut pas dépasser le total de " . number_format($total_vente, 2));
        }

        // ================================================================
        // TRANSACTION COMPLÈTE
        // ================================================================
        $db->begin();
        $db_in_transaction = true;

        // 1️⃣ GÉNÉRER RÉFÉRENCE SORTIE
        $resRef = $db->query("SELECT ref FROM ".MAIN_DB_PREFIX."pech_sortie ORDER BY rowid DESC LIMIT 1");
        $ref_base = '';
        if ($resRef && $db->num_rows($resRef) > 0) {
            $objRef = $db->fetch_object($resRef);
            $ref_base = $objRef->ref;
        }
        $nextNumber = (!empty($ref_base) && preg_match('/SO-(\d+)/', $ref_base, $m)) ? ((int)$m[1] + 1) : 1;
        $ref_sortie = 'SO-' . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);

        // 2️⃣ CRÉER LA SORTIE (type=1 pour client)
        $fk_client_sql = ($fk_client > 0) ? $fk_client : 'NULL';
        $sql_sortie = "INSERT INTO ".MAIN_DB_PREFIX."pech_sortie
                       (ref, type, fk_entrepot_source, fk_client, fk_user, statut, poids_total, nb_carton_total, entity)
                       VALUES
                       ('" . $db->escape($ref_sortie) . "', 1, " . $entrepot_source . ", " . $fk_client_sql . ",
                        " . $user->id . ", 1, " . $poids_total . ", " . $nb_carton_total . ", " . $conf->entity . ")";

        if (!$db->query($sql_sortie)) {
            throw new Exception("Erreur création sortie: " . $db->lasterror());
        }

        $fk_sortie = $db->last_insert_id(MAIN_DB_PREFIX . 'pech_sortie');

        // 3️⃣ CRÉER LES DÉTAILS DES PRODUITS
        foreach ($product_lines as $line) {
            $sql_det = "INSERT INTO ".MAIN_DB_PREFIX."pech_sortiedetprod
                        (fk_sortie, fk_product, nb_carton, poids_total, pu, statut, entity)
                        VALUES
                        (" . $fk_sortie . ", " . $line['product_id'] . ", " . $line['nb_carton'] . ",
                         " . $line['poids'] . ", " . $line['prix_carton'] . ", 0, " . $conf->entity . ")";

            if (!$db->query($sql_det)) {
                throw new Exception("Erreur création détail produit: " . $db->lasterror());
            }

            $fk_sortiedetprod = $db->last_insert_id(MAIN_DB_PREFIX . 'pech_sortiedetprod');

            // Créer les cartons pour ce produit (on sélectionne les cartons disponibles)
            $sql_cartons = "SELECT c.rowid FROM ".MAIN_DB_PREFIX."pech_carton c
                           INNER JOIN ".MAIN_DB_PREFIX."pech_lotdet ld ON ld.rowid = c.fk_lotdet
                           INNER JOIN ".MAIN_DB_PREFIX."pech_lot l ON l.rowid = ld.fk_lot
                           WHERE c.fk_product = " . $line['product_id'] . "
                           AND l.fk_entrepot = " . $line['entrepot'] . "
                           AND c.statut = 0
                           LIMIT " . $line['nb_carton'];

            $res_cartons = $db->query($sql_cartons);
            $carton_count = 0;
            $cartons_ids = array();

            if ($res_cartons) {
                while ($obj_carton = $db->fetch_object($res_cartons)) {
                    $sql_carton_det = "INSERT INTO ".MAIN_DB_PREFIX."pech_sortiedetcarton
                                      (fk_sortiedetprod, fk_carton, poids, statut, entity)
                                      VALUES
                                      (" . $fk_sortiedetprod . ", " . $obj_carton->rowid . ", 25, 0, " . $conf->entity . ")";

                    if (!$db->query($sql_carton_det)) {
                        throw new Exception("Erreur création carton: " . $db->lasterror());
                    }

                    $cartons_ids[] = $obj_carton->rowid;
                    $carton_count++;
                    if ($carton_count >= $line['nb_carton']) break;
                }
            }

            // Marquer les cartons comme utilisés (statut = 1)
            if (!empty($cartons_ids)) {
                $sql_update_cartons = "UPDATE ".MAIN_DB_PREFIX."pech_carton SET statut = 1
                                       WHERE rowid IN (" . implode(',', $cartons_ids) . ")";
                if (!$db->query($sql_update_cartons)) {
                    throw new Exception("Erreur mise à jour statut cartons: " . $db->lasterror());
                }
            }

            // Mouvement de stock
            if ($line['entrepot'] > 0) {
                $sql_stock = "INSERT INTO ".MAIN_DB_PREFIX."stock_mouvement
                             (datem, type_mouvement, fk_product, fk_entrepot, value, description, fk_user_author, ref_source)
                             VALUES
                             (NOW(), 0, " . $line['product_id'] . ", " . $line['entrepot'] . ",
                              -" . $line['nb_carton'] . ", 'Vente Client " . $ref_sortie . "',
                              " . $user->id . ", '" . $db->escape($ref_sortie) . "')";

                $db->query($sql_stock);
            }
        }

        // 4️⃣ CRÉER LA FACTURE (si client sélectionné)
        $facture_ref = '';
        if ($fk_client > 0) {
            $facture = new Facture($db);
            $facture->socid = $fk_client;
            $facture->type = 0; // Facture standard
            $facture->date = dol_now();
            $facture->note_public = "Vente Client - Sortie: " . $ref_sortie;

            $fk_facture = $facture->create($user);
            if ($fk_facture <= 0) {
                throw new Exception("Erreur création facture: " . $facture->error);
            }

            // 5️⃣ CRÉER LES LIGNES DE FACTURE
            foreach ($product_lines as $line) {
                $product = new Product($db);
                if ($product->fetch($line['product_id']) > 0) {
                    $desc_line = $product->label;
                } else {
                    $desc_line = "Produit #" . $line['product_id'];
                }

                $resLine = $facture->addline(
                    $desc_line,              // desc
                    $line['prix_carton'],    // pu
                    0,                       // tva_tx
                    0,                       // localtax1_type
                    0,                       // localtax2_type
                    $line['nb_carton'],      // qty
                    $line['product_id'],     // fk_product
                    0,                       // remise_percent
                    0,                       // date_start
                    0,                       // date_end
                    0,                       // fk_code_ventilation
                    0                        // info_bits
                );

                if ($resLine < 0) {
                    throw new Exception("Erreur création ligne facture: " . $facture->error);
                }
            }

            // Valider la facture
            $resVal = $facture->validate($user);
            if ($resVal < 0) {
                throw new Exception("Erreur validation facture: " . $facture->error);
            }

            $facture_ref = $facture->ref;
        }

        // Valider la transaction
        $db->commit();
        $db_in_transaction = false;

        // ================================================================
        // SUCCÈS - REDIRECTION
        // ================================================================
        setEventMessages("Sortie créée: " . $ref_sortie, '', 'mesgs');
        setEventMessages("Statut: VALIDÉE", '', 'mesgs');
        if ($facture_ref) {
            setEventMessages("Facture créée: " . $facture_ref, '', 'mesgs');
        } else {
            setEventMessages("Aucune facture créée (pas de client sélectionné)", '', 'mesgs');
        }
        setEventMessages(count($product_lines) . " produit(s), " . $nb_carton_total . " carton(s)", '', 'mesgs');

        header("Location: ../sortie/list.php");
        exit;

    } catch (Exception $e) {
        if ($db_in_transaction) {
            $db->rollback();
        }

        dol_syslog("Erreur vente client: " . $e->getMessage(), LOG_ERR);
        setEventMessages($e->getMessage(), '', 'errors');

        header("Location: sortie_client.php");
        exit;
    }
}

// ============================================================================
// FORMULAIRE DE CRÉATION
// ============================================================================
llxHeader('', 'Vente Client');
print '<link rel="stylesheet" href="../selection_form_style.css">';
print '<div class="selection-container">';
print '<div class="selection-header">';
print '<h1>Créer une Vente Client</h1>';
// print '<p style="opacity: 0.8;">Création, validation et facturation en une seule étape</p>';
print '</div>';

// Données
$clients = array();
$sql = "SELECT rowid, nom FROM ".MAIN_DB_PREFIX."societe WHERE client = 1 AND entity = ".$conf->entity." ORDER BY nom";
$resql = $db->query($sql);
if ($resql) {
    while ($obj = $db->fetch_object($resql)) $clients[$obj->rowid] = $obj->nom;
}

$produits = array();
$sql = "SELECT p.rowid, p.label FROM ".MAIN_DB_PREFIX."product p
        INNER JOIN ".MAIN_DB_PREFIX."categorie_product cp ON cp.fk_product = p.rowid
        INNER JOIN ".MAIN_DB_PREFIX."categorie c ON c.rowid = cp.fk_categorie
        WHERE c.label = 'POISSON' AND p.entity = ".$conf->entity." ORDER BY p.label";
$resql = $db->query($sql);
if ($resql) {
    while ($obj = $db->fetch_object($resql)) $produits[$obj->rowid] = $obj->label;
}

// Récupérer les entrepôts accessibles par l'utilisateur
$entrepots = array();

// Vérifier si l'utilisateur est admin (a accès à tous les entrepôts)
$is_admin = $user->admin;

if ($is_admin) {
    // Admin: accès à tous les entrepôts
    $sql = "SELECT rowid, ref FROM ".MAIN_DB_PREFIX."entrepot WHERE entity = ".$conf->entity;
} else {
    // Utilisateur simple: seulement ses entrepôts assignés
    $sql = "SELECT DISTINCT e.rowid, e.ref
            FROM ".MAIN_DB_PREFIX."entrepot e
            INNER JOIN ".MAIN_DB_PREFIX."user_entrepot ue ON ue.fk_entrepot = e.rowid
            WHERE ue.fk_user = " . $user->id . " AND e.entity = " . $conf->entity;
}

$resql = $db->query($sql);
if ($resql) {
    while ($obj = $db->fetch_object($resql)) {
        $entrepots[$obj->rowid] = $obj->ref;
    }
}

// Formulaire
print '<form method="post" action="sortie_client.php" id="formVente">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="create">';

// CLIENT
print '<div class="filter-section">';
print '<div class="filter-title">1. Client (optionnel)</div>';
print '<table class="filter-table">';
print '<tr><td width="30%"><label><strong>Client</strong></label></td>';
print '<td>'.$form->selectarray('fk_client_dest', array('' => 'Pas de client') + $clients, '', '', 0, 0, '', 'filter-input').'</td></tr>';
print '</table>';
print '</div>';

// PRODUITS
print '<div class="filter-section">';
print '<div class="filter-title">2. Produits</div>';
print '<div class="selection-table-container">';
print '<table class="selection-table" id="tableProduits">';
print '<thead><tr>';
print '<th class="center">N° Camion</th>';
print '<th>Produit</th>';
print '<th class="center">Entrepôt Source</th>';
print '<th class="center">Cartons</th>';
print '<th class="center">Prix/Carton</th>';
print '<th class="center">Total</th>';
print '<th class="center">Stock</th>';
print '<th class="center">Action</th>';
print '</tr></thead>';
print '<tbody></tbody>';
print '</table>';
print '</div>';
print '<div class="selection-actions">';
print '<button type="button" class="selection-button selection-button-success" onclick="addRow()">Ajouter produit</button>';
print '</div>';
print '</div>';

// RÉSUMÉ
print '<div class="filter-section" style="background: #e8f5e9; border-left: 4px solid #4caf50;">';
print '<div class="filter-title">3. Résumé</div>';
print '<table class="filter-table">';
print '<tr>';
print '<td width="30%"><label><strong>Total TTC</strong></label></td>';
print '<td><input type="text" id="totalVente" readonly value="0.00" style="font-weight: bold; font-size: 16px; color: #4caf50;"> MU</td>';
print '</tr>';
print '<tr>';
print '<td width="30%"><label><strong>Montant Payé</strong></label></td>';
print '<td><input type="number" id="montantPaye" name="montant_paye" value="0" step="0.01" min="0" oninput="updateResteAPayer()" style="font-size: 14px;"> MU</td>';
print '</tr>';
print '<tr>';
print '<td width="30%"><label><strong>Reste à Payer</strong></label></td>';
print '<td><input type="text" id="resteAPayer" readonly value="0.00" style="font-weight: bold; font-size: 16px; color: #ff9800;"> MU</td>';
print '</tr>';
print '</table>';
print '</div>';

// BOUTON
print '<div class="selection-actions">';
print '<button type="submit" class="selection-button selection-button-primary" style="background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%); padding: 15px 30px; font-size: 16px;">Créer</button>';
print '</div>';

print '</form>';
print '</div>';

?>
<style>
#tableProduits { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
#tableProduits tr { background: #f9fafb; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); }
#tableProduits tr:hover { background: #eef2ff; }
#tableProduits td { padding: 12px; vertical-align: middle; }
#tableProduits select, #tableProduits input { width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; }
.center { text-align: center; }
</style>

<script>
var selectProduit = <?php echo json_encode(str_replace("\n", '', $form->selectarray('products[]', array('' => '') + $produits, '', 0, 0, 0, '', 0, 0, 0, '', 'minwidth150'))); ?>;
var selectEntrepot = <?php echo json_encode(str_replace("\n", '', $form->selectarray('fk_entrepot_source_prod[]', $entrepots, '', 0, 0, 0, '', 0, 0, 0, '', 'minwidth150'))); ?>;

function addRow() {
    var tbody = document.getElementById('tableProduits').getElementsByTagName('tbody')[0];
    var row = tbody.insertRow(-1);

    row.insertCell(0).className = 'center'; row.cells[0].innerHTML = '<input type="text" name="numero_camion_prod[]" value="" placeholder="CM-001" style="width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px;">';
    row.insertCell(1).innerHTML = selectProduit;
    row.insertCell(2).className = 'center'; row.cells[2].innerHTML = selectEntrepot;
    row.insertCell(3).className = 'center'; row.cells[3].innerHTML = '<input type="number" name="nb_carton[]" value="0" min="0" class="carton-input" oninput="calcLigne(this)">';
    row.insertCell(4).className = 'center'; row.cells[4].innerHTML = '<input type="number" name="prix_carton[]" value="0" step="0.01" min="0" class="prix-input" oninput="calcLigne(this)">';
    row.insertCell(5).className = 'center'; row.cells[5].innerHTML = '<span class="total-ligne">0.00</span> MU';
    row.insertCell(6).className = 'center'; row.cells[6].innerHTML = '<span class="stock-dispo">-</span>';
    row.insertCell(7).className = 'center'; row.cells[7].innerHTML = '<button type="button" class="remove-btn" onclick="this.closest(\'tr\').remove(); calcTotal()" style="background: #ef4444; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; width: 100%;"><i class="fa fa-trash"></i></button>';

    // Attach listeners to new selects
    row.querySelector('select[name="products[]"]').addEventListener('change', function() { updateStock(this); });
    row.querySelector('select[name="fk_entrepot_source_prod[]"]').addEventListener('change', function() { updateStock(this); });
}

function calcLigne(el) {
    var row = el.closest('tr');
    var cartons = parseFloat(row.querySelector('.carton-input').value) || 0;
    var prix = parseFloat(row.querySelector('.prix-input').value) || 0;
    var total = cartons * prix;
    row.querySelector('.total-ligne').textContent = total.toFixed(2);
    calcTotal();
}

function updateStock(el) {
    var row = el.closest('tr');
    var prodSelect = row.querySelector('select[name="products[]"]');
    var entSelect = row.querySelector('select[name="fk_entrepot_source_prod[]"]');
    var stockSpan = row.querySelector('.stock-dispo');

    var product_id = parseInt(prodSelect.value);
    var fk_entrepot = parseInt(entSelect.value);

    if (!product_id || !fk_entrepot) {
        stockSpan.textContent = '-';
        return;
    }

    fetch('ajax.php?product_id=' + product_id + '&fk_entrepot=' + fk_entrepot)
    .then(r => r.json())
    .then(data => {
        stockSpan.textContent = data.nb_carton_dispo + ' cartons';
    })
    .catch(() => { stockSpan.textContent = 'Erreur'; });
}

function calcTotal() {
    var total = 0;
    document.querySelectorAll('#tableProduits tbody tr').forEach(function(row) {
        var ligne = parseFloat(row.querySelector('.total-ligne').textContent) || 0;
        total += ligne;
    });
    document.getElementById('totalVente').value = total.toFixed(2);
    updateResteAPayer();
}

function updateResteAPayer() {
    var total = parseFloat(document.getElementById('totalVente').value) || 0;
    var montantPaye = parseFloat(document.getElementById('montantPaye').value) || 0;

    // Valider que montant payé ne dépasse pas le total
    if (montantPaye > total) {
        document.getElementById('montantPaye').value = total.toFixed(2);
        montantPaye = total;
    }

    var reste = total - montantPaye;
    document.getElementById('resteAPayer').value = reste.toFixed(2);
}

document.getElementById('formVente').addEventListener('submit', function(e) {
    e.preventDefault();

    var rows = document.querySelectorAll('#tableProduits tbody tr').length;
    var totalVente = parseFloat(document.getElementById('totalVente').value) || 0;
    var montantPaye = parseFloat(document.getElementById('montantPaye').value) || 0;

    if (rows === 0) {
        alert('Ajoutez au moins un produit');
        return false;
    }
    if (totalVente <= 0) {
        alert('Vérifiez les quantités et prix');
        return false;
    }
    if (montantPaye > totalVente) {
        alert('Montant payé ne peut pas dépasser le total');
        return false;
    }

    this.submit();
});
</script>

<?php
llxFooter();
$db->close();
?>
